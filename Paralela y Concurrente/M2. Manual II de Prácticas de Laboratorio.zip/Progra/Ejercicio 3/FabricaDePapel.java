import java.util.Random;

class Persona extends Thread {
    private Caja caja;
    private int id;
    private Random random;

    public Persona(Caja caja, int id) {
        this.caja = caja;
        this.id = id;
        this.random = new Random();
    }

    public void run() {
        while (true) {
            int hojas = 1;
            caja.colocarHojas(id, hojas);
            try {
                sleep(random.nextInt(250) + 1);
            } catch (InterruptedException e) {}
        }
    }
}

class Vaciador extends Thread {
    private Caja caja;

    public Vaciador(Caja caja)
    {
        this.caja = caja;
    }

    public void run() {
        while (true) {
            caja.vaciarCaja();
            try {
                sleep(1000);
            } catch (InterruptedException e) {}
        }
    }
}

class Caja {
    private int[] hojas;
    private int totalHojas;
    private final int capacidad = 100;

    public Caja() {
        hojas = new int[3];
        totalHojas = 0;
    }

    public synchronized void colocarHojas(int id, int cantidad) {
        while (totalHojas + cantidad > capacidad) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }

        hojas[id] += cantidad;
        totalHojas += cantidad;
        System.out.println("Persona " + id + " colocó " + cantidad + " hojas. Total en la caja: " + totalHojas);
        notifyAll();
    }

    public synchronized void vaciarCaja() {
        while (totalHojas < capacidad) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }

        System.out.println("Se ha vaciado la caja. Hojas colocadas: " + hojas[0] + " + " + hojas[1] + " + " + hojas[2] + " = " + totalHojas);
        totalHojas = 0;
        hojas[0] = 0;
        hojas[1] = 0;
        hojas[2] = 0;
        notifyAll();
    }
}

public class FabricaDePapel {
    public static void main(String[] args) {
        Caja caja = new Caja();

        Persona p1 = new Persona(caja, 0);
        Persona p2 = new Persona(caja, 1);
        Persona p3 = new Persona(caja, 2);
        Vaciador vaciador = new Vaciador(caja);

        p1.start();
        p2.start();
        p3.start();
        vaciador.start();
    }
}