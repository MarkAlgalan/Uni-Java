/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.casahermanoscomelones2;

/**
 *
 * @author nuria
 */
import java.util.Random;

class Casa {
    private int numHermanos;//Un entero que representa el número de hermanos en la casa
    private int capacidadCacerola;//Un entero que representa la cantidad máxima de porciones que puede contener la cacerola.
    private volatile int racionesDisponibles;//Un entero volátil que representa la cantidad actual de porciones disponibles en la cacerola.
    private Random random;//Un objeto de la clase Random utilizado para generar números aleatorios.

    public Casa(int numHermanos) {
        this.numHermanos = numHermanos;//Inicializa el número de hermanos y el objeto Random.
        this.random = new Random();
        this.capacidadCacerola = 0;//Establece la capacidad y las raciones disponibles de la cacerola en 0.
        this.racionesDisponibles = 0;
    }
//Método sincronizado que simula a un hermano comiendo de la cacerola.
    public synchronized void comer(int id) {
        while (racionesDisponibles == 0) {//Mientras no haya raciones disponibles, el hermano espera.
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("Hermano " + id + " ha sido interrumpido mientras esperaba.");
                return;
            }
        }

        // Generar un número aleatorio entre 1 y raciones disponibles para las porciones a comer
        int porcionesAComer = random.nextInt(racionesDisponibles) + 1;
        racionesDisponibles -= porcionesAComer;//Reduce las raciones disponibles en función de las porciones consumidas.
        
        //Imprime un mensaje indicando cuántas porciones come el hermano y cuántas quedan.
        System.out.println("Hermano " + id + " está comiendo " + porcionesAComer + " porciones. Quedan " + racionesDisponibles + " porciones en la cacerola.");

        // Simulamos el tiempo que tarda en comer
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println("Hermano " + id + " ha sido interrumpido mientras comía.");
        }

        System.out.println("Hermano " + id + " ha terminado de comer.");//Notifica a todos los hilos esperando (otros hermanos) que la cacerola ha sido modificada.

        notifyAll();
    }
    
    // Método sincronizado que simula al cocinero rellenando la cacerola.
    public synchronized void rellenarCacerola() {
        this.capacidadCacerola = random.nextInt(20) + 1; // Capacidad aleatoria entre 1 y 20 a la cacerola
        this.racionesDisponibles = capacidadCacerola;// Establece las raciones disponibles igual a la capacidad.
        System.out.println("Cocinero ha rellenado la cacerola con " + racionesDisponibles + " porciones disponibles."); // Imprime un mensaje indicando cuántas porciones están disponibles.
        notifyAll();// Notifica a todos los hilos esperando (hermanos) que la cacerola ha sido rellenada.
    }
}


// Representa a un hermano en la casa.
class Hermano extends Thread {
    private int id;
    private Casa casa;

    
    //Constructor que inicializa el identificador del hermano y la referencia a la casa.
    public Hermano(int id, Casa casa) {
        this.id = id;
        this.casa = casa;
    }
    
    
    //Define el comportamiento del hilo del hermano.
    @Override
    public void run() {
        while (true) {
            try {
                casa.comer(id);//Repetidamente llama al método comer() de la casa.
                System.out.println("Hermano " + id + " está limpiando la casa.");//MAnda el mensaje de que el hermano esta limpiando la casa despues de comer
                Thread.sleep(5000); // Simulamos el tiempo que tarda en limpiar la casa
            } catch (InterruptedException e) {
                System.out.println("Hermano " + id + " ha sido interrumpido mientras limpiaba la casa.");
            }
        }
    }
}


//Representa al cocinero de la casa.
class Cocinero extends Thread {
    private Casa casa;

    
    //Constructor que inicializa la referencia a la casa.
    public Cocinero(Casa casa) {
        this.casa = casa;
    }

    
    //Define el comportamiento del hilo del cocinero.
    @Override
    public void run() {
        while (true) {
            casa.rellenarCacerola();//Repetidamente llama al método rellenarCacerola() de la casa.
            try {
                Thread.sleep(3000); // Simulamos el tiempo que tarda en rellenar la cacerola
            } catch (InterruptedException e) {
                System.out.println("El cocinero ha sido interrumpido mientras rellenaba la cacerola.");
            }
        }
    }
}


//Clase inicial
public class CasaHermanosComelones2 {
    public static void main(String[] args) {
        Casa casa = new Casa(5);//Crea una instancia de Casa con 5 hermanos

        Cocinero cocinero = new Cocinero(casa);//Crea una instancia de Cocinero y lo inicia en un hilo separado.
        cocinero.start();

        for (int i = 1; i <= 5; i++) {//Crea e inicia un hilo para cada hermano.
            Hermano hermano = new Hermano(i, casa);
            hermano.start();
        }
    }
}
