public class Sumador extends Thread{
  private int num;
  private Suma sumaGen;
  public Sumador(Suma sum,int num){
    this.num=num;
    this.sumaGen=sum;
  }
  public void run(){
    try {
      sleep(100*num);
    } catch (Exception e) {}
    sumaGen.sumar(num);
    System.out.println("Sumador "+num+" ha sumado.\nSuma: "+sumaGen.getSuma());
  }
}