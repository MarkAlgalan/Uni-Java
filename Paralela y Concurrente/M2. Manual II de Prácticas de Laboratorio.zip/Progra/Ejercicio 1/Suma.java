public class Suma {
  private int suma;
  private int ultimo;
  public Suma(int ultimo){
    this.ultimo=ultimo;
    suma=0;
  }
  public synchronized int getSuma() {
    return suma;
  }
  public synchronized void sumar(int num){
    while (ultimo!=num-1) {
      try {
        wait();
      } catch (Exception e) {}
    }
    suma=suma+num;
    ultimo = num;
    notifyAll();
  }
  public static void main(String[] args) {
    int n = 10;
    Suma s = new Suma(0);
    Sumador [] sums = new Sumador[n];
    for (int i = 0; i < n; i++) {
      sums[i] = new Sumador(s, i+1); 
    }

    for (int i = 0; i < n; i++) {
      sums[i].start(); 
    }

    for (int i = 0; i < n; i++) {
      try {
      sums[i].join();
      } catch (Exception e) {}
    }
  }
}