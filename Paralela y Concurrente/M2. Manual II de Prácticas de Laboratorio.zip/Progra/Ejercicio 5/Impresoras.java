package escuela.impresoras;
import java.util.Random;
class ImpresoraA {
    int impresosA = 0;
    boolean ocupada;
    public void usar(){
        ocupada = true;
    }
    public boolean getEstado (){
        return ocupada;
    }
    public void dejarUsar(){
        ocupada = false;
    }
    public void imprimir(){
        impresosA++;
        //System.out.println("La impresora A ha impreso "+impresosA+" papeles");
    }
}

class ImpresoraB{
    int impresosB = 0;
    boolean ocupada;
    public void usar(){
        ocupada = true;
    }
    
    public boolean getEstado (){
        return ocupada;
    }
    public void dejarUsar(){
        ocupada = false;
    }
    public void imprimir(){
        impresosB++;
        //System.out.println("La impresora B ha impreso "+impresosB+" papeles");
    }
}

class tA extends Thread{
    ImpresoraA impreA;
    tA(ImpresoraA impreA){
       this.impreA = impreA;
    }
    public void run(){
        while(true){
            
            synchronized(impreA){
                while(impreA.getEstado() == true){ //¿Esta ocupada?
                    try{
                        impreA.wait();
                    }catch(InterruptedException e){}
                }
                impreA.usar();
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){e.printStackTrace();}
                
                System.out.println("TA uso la A");
                //Hace la simulación de imprimir y la suelta
                impreA.imprimir();
                impreA.dejarUsar();
                impreA.notifyAll();
            }
            
            try{
                    Thread.sleep((int)((Math.random()*1000)+1));
            }catch(InterruptedException e){e.printStackTrace();}
        }

    }
}

class tB extends Thread{
    ImpresoraB impreB;
    tB(ImpresoraB impreB){
       this.impreB = impreB;
    }
    public void run(){
        while(true){
            synchronized(impreB){
                while(impreB.getEstado() == true){
                    try{
                        impreB.wait();
                    }catch(InterruptedException e){}
                    
                }
                impreB.usar();
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){e.printStackTrace();}
                System.out.println("TB uso la B");
                impreB.imprimir();
                impreB.dejarUsar();
            }
            
            try{
                    Thread.sleep((int)((Math.random()*1000)+1));
            }catch(InterruptedException e){e.printStackTrace();}
     
        }
    }
}

class tAB extends Thread{
    ImpresoraA impreA;
    ImpresoraB impreB;
    Random Juan;
    tAB(ImpresoraA impreA, ImpresoraB impreB){
        this.impreA = impreA;
        this.impreB = impreB;
        Juan = new Random();
    }
    public void run(){
        int ale;
        while(true){
            ale=Juan.nextInt(2);
            if(ale==0){
                synchronized(impreA){
                    if(impreA.getEstado() != true){
                        impreA.usar();
                        try{
                            Thread.sleep(1000);
                        }catch(InterruptedException e){e.printStackTrace();}
                        System.out.println("TAB uso la A OH YEAH");
                        impreA.imprimir();
                        impreA.dejarUsar();
                        impreA.notifyAll();
                    }
                }
                synchronized(impreB){
                    if(!impreB.getEstado()){
                        impreB.usar();
                        try{
                            Thread.sleep(1000);
                        }catch(InterruptedException e){e.printStackTrace();}
                        System.out.println("TAB uso la B CREEPER");
                        impreB.imprimir();
                        impreB.dejarUsar();
                        impreB.notifyAll();
                    }
                }
                try{
                        Thread.sleep((int)((Math.random()*10)+1));
                }catch(InterruptedException e){e.printStackTrace();}
            }else{   
                synchronized(impreB){
                    if(!impreB.getEstado()){
                        impreB.usar();
                        try{
                            Thread.sleep(1000);
                        }catch(InterruptedException e){e.printStackTrace();}
                        System.out.println("TAB uso la B CREEPER");
                        impreB.imprimir();
                        impreB.dejarUsar();
                        impreB.notifyAll();
                    }
                }
                 synchronized(impreA){
                    if(impreA.getEstado() != true){
                        impreA.usar();
                        try{
                            Thread.sleep(1000);
                        }catch(InterruptedException e){e.printStackTrace();}
                        System.out.println("TAB uso la A OH MAN");
                        impreA.imprimir();
                        impreA.dejarUsar();
                        impreA.notifyAll();
                    }
                }
                try{
                        Thread.sleep((int)((Math.random()*10)+1));
                }catch(InterruptedException e){e.printStackTrace();}
            } 
        }
    }
}


public class Impresoras extends Thread {
    
    public static void main(String[] args) {
        ImpresoraA A = new ImpresoraA();
        ImpresoraB B = new ImpresoraB();
        tA ta = new tA(A) ;
        tB tb = new tB(B);
        tAB tab = new tAB(A,B);
        
        ta.start();
        tb.start();
        tab.start();
    }
}
