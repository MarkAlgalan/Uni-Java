
package estructuras.pares;
import java.util.Scanner;


class Sumador extends Thread{
    int numHilo;
    recompartido recurso;
    
    public Sumador(recompartido recurso, int numHilo){
        this.recurso = recurso;
        this.numHilo = numHilo;
    }
    
    public void run(){
        
        while(true){
            synchronized(recurso){
            recurso.valor = recurso.valor + 2;
            System.out.println("El hilo numero: \t" + numHilo + "\t sumo 2 y el total es \t" + recurso.valor);   
            recurso.notifyAll();
            try{ recurso.wait();}catch(InterruptedException e){}
            }    
        }
    }
}

class recompartido{
    int valor;
}


public class Pares {
    
    public static void main(String[] args) {
        
        recompartido recurso = new recompartido();
        
        System.out.println("¿Cuantos Hilos quieres generar?");
        Scanner leer = new Scanner(System.in);
        int numHilos = leer.nextInt();
        
        
        for(int i = 1; i <= numHilos; i++){
            Sumador hilo = new Sumador(recurso, i);
            hilo.start();
        }
    }
}
