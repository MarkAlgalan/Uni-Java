package M2manual;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Clase que realiza la suma paralela
class SumaParalela {
    private List<Integer> numerosCompartidos; // Lista de números compartidos entre los matemáticos
    private List<Matematico> matematicos; // Lista de matemáticos
    private int sumaTotal; // Suma total de todos los matemáticos
    private int matematicosTerminados; // Contador de matemáticos que han terminado

    // Constructor de la clase SumaParalela
    public SumaParalela(int cantidadNumeros, int cantidadMatematicos) {
        numerosCompartidos = new ArrayList<>();
        matematicos = new ArrayList<>();
        sumaTotal = 0;
        matematicosTerminados = 0;

        // Llenar el arreglo compartido con los números naturales del 1 al n
        for (int i = 1; i <= cantidadNumeros; i++) {
            numerosCompartidos.add(i);
        }

        // Ajustar la cantidad de matemáticos si es mayor que la cantidad de números
        cantidadMatematicos = Math.min(cantidadMatematicos, cantidadNumeros);

        // Crear a los matemáticos
        for (int i = 0; i < cantidadMatematicos; i++) {
            matematicos.add(new Matematico("Matematico " + (i + 1)));
        }
    }

    // Método para obtener el siguiente número de la lista compartida
    public synchronized int obtenerSiguienteNumero() {
        // Obtener un número aleatorio del arreglo compartido
        if (!numerosCompartidos.isEmpty()) {
            int indice = new Random().nextInt(numerosCompartidos.size());
            int numero = numerosCompartidos.remove(indice);
            return numero;
        }
        return -1; // Retornar -1 si no hay más números disponibles
    }

    // Método para agregar la suma parcial de un matemático a la suma total
    public synchronized void agregarSumaParcial(int sumaParcial) {
        sumaTotal += sumaParcial;
        matematicosTerminados++;
        if (matematicosTerminados == matematicos.size()) {
            notify(); // Notificar cuando todos los matemáticos han terminado
        }
    }

    // Método para iniciar el proceso de suma paralela
    public void empezarSumaParalela() {
        // Imprimir el número de matemáticos y el arreglo original y ordenado de los números
        System.out.println("Número de matemáticos: " + matematicos.size());
        System.out.println("Arreglo original: " + numerosCompartidos);

        // Iniciar a cada matemático
        for (Matematico matematico : matematicos) {
            matematico.start();
        }

        synchronized (this) {
            // Esperar a que todos los matemáticos terminen
            while (matematicosTerminados < matematicos.size()) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Imprimir los resultados y la suma total
            System.out.println("Resultados:");
            for (Matematico matematico : matematicos) {
                System.out.println(matematico.getNombre() + ": Suma = " + matematico.getSumaParcial() + ", Números = " + matematico.getNumerosTomados());
            }
            System.out.println("Suma total: " + sumaTotal);
        }
    }

    // Clase interna que representa un matemático
    class Matematico extends Thread {
        private String nombre; // Nombre del matemático
        private List<Integer> numerosTomados; // Lista de números tomados por el matemático
        private int sumaParcial; // Suma parcial del matemático

        // Constructor de la clase Matematico
        public Matematico(String nombre) {
            this.nombre = nombre;
            this.numerosTomados = new ArrayList<>();
            this.sumaParcial = 0;
        }

        // Método para obtener el nombre del matemático
        public String getNombre() {
            return nombre;
        }

        // Método para obtener la suma parcial del matemático
        public int getSumaParcial() {
            return sumaParcial;
        }

        // Método para obtener la lista de números tomados por el matemático
        public List<Integer> getNumerosTomados() {
            return numerosTomados;
        }

        // Método que se ejecuta cuando se inicia el hilo del matemático
        public void run() {
            int numero;
            while ((numero = obtenerSiguienteNumero()) != -1) {
                numerosTomados.add(numero);
                // Simular proceso de suma parcial
                sumaParcial += numero;
                // Simular tiempo de procesamiento
                try {
                    Thread.sleep(new Random().nextInt(100));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            agregarSumaParcial(sumaParcial); // Agregar la suma parcial a la suma total
        }
    }
}

// Clase principal
public class Matematicos {
    // Método principal
    public static void main(String[] args) {
        Random random = new Random();
        int cantidadNumeros = random.nextInt(20) + 1; // Cantidad de números aleatoria entre 1 y 20
        int cantidadMatematicos = random.nextInt(cantidadNumeros) + 1; // Cantidad de matemáticos aleatoria entre 1 y cantidadNumeros
        SumaParalela sumaParalela = new SumaParalela(cantidadNumeros, cantidadMatematicos);
        sumaParalela.empezarSumaParalela(); // Iniciar la suma paralela
    }
}
