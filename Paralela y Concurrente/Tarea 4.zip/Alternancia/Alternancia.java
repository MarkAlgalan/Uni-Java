package com.mycompany.alternancia;

class Contador {
    volatile int x, turno;

    public Contador(int x, int turno) {
        this.x = x;
        this.turno = turno;
    }

    public int getContador() {
        return x;
    }

    public void incContador() {
        x++;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
}

class Puerta extends Thread {
    Contador cnt;
    int id, repeticiones;

    public Puerta(int id, int repeticiones, Contador cnt) {
        this.id = id;
        this.repeticiones = repeticiones;
        this.cnt = cnt;
    }

    public void run() {
        for (int i = 0; i < repeticiones; i++) {
            while (cnt.getTurno() != id) {
                // Espera activa
            }

            if (cnt.getContador() < repeticiones * 2) {
                cnt.incContador();
                System.out.println("Puerta " + id + " Entra una persona " + cnt.getContador());
            }

            if (id == 1) {
                cnt.setTurno(2);
            } else {
                cnt.setTurno(1);
            }

            try {
                sleep((long) (Math.random() * 500 + 1));
            } catch (InterruptedException e) {
            }
        }
    }
}

public class Alternancia {
    public static void main(String args[]) {
        Contador cont = new Contador(0, 1);
        int repeticiones = 50;
        Puerta p1 = new Puerta(1, repeticiones, cont);
        Puerta p2 = new Puerta(2, repeticiones, cont);

        p1.start();
        p2.start();

        try {
            p1.join();
            p2.join();
        } catch (InterruptedException e) {
        }

        System.out.println("\nNumero total de personas: " + cont.getContador());
    }
}


