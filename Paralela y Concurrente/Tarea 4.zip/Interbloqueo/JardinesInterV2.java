
package com.mycompany.jardinesinterv2;

import static java.lang.Thread.sleep;
public class JardinesInterV2 {

    public static void main(String args[]){
    Contador c = new Contador(0,0,1);
    Puerta p1 = new Puerta("Puerta 1", c);
    Puerta2 p2 = new Puerta2("PUERTA 2", c);

    p1.start();
    p2.start();
    try{
      p1.join();
      p2.join();
    }catch(InterruptedException e){}
    System.out.println("TOTAL DE PERSONAS EN LOS JARDINES: " + c.getX());
  }
}
class Contador 
  {
    int x,pro1,pro2;
    public Contador(int x, int pro1,int pro2 )
    {
      this.x = x;
      this.pro1=pro1;
      this.pro2=pro2;
    }
    public void setX(int x)
    {
      this.x = x;
    }
    public int getX(){
      return x;
    }
    public void setpro(int pro1)
    {
      this.pro1 = pro1;
    }
    public int getpro(){
      return pro1;
    }
    public void setpro2(int pro2)
    {
      this.pro2 = pro2;
    }
    public int getpro2(){
      return pro2;
    }
   
  }

class Puerta extends Thread{
    String name;
    Contador cnt;
    public Puerta (String name, Contador cnt ){
      this.name = name;
      this.cnt = cnt; 
    }
    public void run(){
        do{
            cnt.setpro(1);
            while(cnt.getpro2()==1){
               try{
                    sleep(300);
                }catch(InterruptedException e){}
            }
            cnt.setX(cnt.getX()+1);
            System.out.println(name + ": Ha ingresado a los jardines... " + cnt.getX());
            cnt.setpro(0);
        }while(cnt.x<25);
        System.out.println("El jardin esta lleno");
    }
}
class Puerta2 extends Thread{
    String name;
    Contador cnt;
    public Puerta2 (String name, Contador cnt ){
      this.name = name;
      this.cnt = cnt; 
    }
    public void run(){
        do{
            cnt.setpro2(1);
            while(cnt.getpro()==1){
               try{
                    sleep(300);
                }catch(InterruptedException e){}
            }
            cnt.setX(cnt.getX()+1);
            System.out.println(name + ": Ha ingresado a los jardines... " + cnt.getX());
            cnt.setpro2(0);
        }while(cnt.x<25);
        System.out.println("El jardin esta lleno");
    }
}
