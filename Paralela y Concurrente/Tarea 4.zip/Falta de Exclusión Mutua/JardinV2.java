import java.lang.Thread;

class Contador{
	int puerta1, puerta2;
	int x;

	public Contador(int p1, int p2, int x){
		puerta1=p1;
		puerta2=p2;
		this.x=x;
	}
	public int getPuerta1(){
		return puerta1;
	}
	public void setPuerta1(int p1){
		puerta1=p1;
	}
	public int getPuerta2(){
		return puerta2;
	}
	public void setPuerta2(int p2){
		puerta2=p2;
	}
	public int getX(){
		return x;
	}
	public void setX(int x){
		this.x=x;
	}
}

class Puerta1 extends Thread{
	Contador cont;
	int limite;
	public Puerta1(Contador c, int l){
		cont=c;
		limite=l*2;
	}
	public void run(){
		while(cont.getX()<limite){
			while(cont.getPuerta2()==1){Thread.yield();}
			cont.setPuerta1(1);
			cont.setX(cont.getX()+1);
			if((cont.getPuerta1()==1)&&(cont.getPuerta2()==0))
				System.out.println("Puerta 1: Alguien ha entrado..."+cont.getX());
			else
				System.out.println("Puerta 1 y Puerta 2: Alguien ha entrado..."+cont.getX());
			cont.setPuerta1(0);
		}
	}
}

class Puerta2 extends Thread{
	Contador cont;
	int limite;
	public Puerta2(Contador c, int l){
		cont=c;
		limite=l*2;
	}
	public void run(){
		while(cont.getX()<limite){
			while(cont.getPuerta1()==1){Thread.yield();}
			cont.setPuerta2(1);
			cont.setX(cont.getX()+1);
			if((cont.getPuerta2()==1)&&(cont.getPuerta1()==0))
				System.out.println("Puerta 2: Alguien ha entrado..."+cont.getX());
			else
				System.out.println("Puerta 1 y Puerta 2: Alguien ha entrado..."+cont.getX());
			cont.setPuerta2(0);
		}
	}
}

class JardinV2{
	public static void main(String args[]){
		Contador c = new Contador(0, 0, 0);
		Puerta1 p1 = new Puerta1(c, 10);
		Puerta2 p2 = new Puerta2(c, 10);
		p1.start();
		p2.start();
		try{
			p1.join();
			p2.join();
		}catch(InterruptedException e){}
		System.out.println("Total de personas en el jardin: " + c.getX());
	}
}