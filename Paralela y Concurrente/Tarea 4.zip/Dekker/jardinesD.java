
class Turnos
 {
  private int pizarra1, pizarra2;
  private int turno;
  
  public Turnos (int pizarra1, int pizarra2, int turno) 
     {
        this.pizarra1=pizarra1;
        this.pizarra2=pizarra2;
        this.turno=turno;
     }
  
  public int getValorPizarra1()
     {
      return pizarra1;
     }
  public int getValorPizarra2()
     {
      return pizarra2;
     }
  public void setValorPizarra1(int valor)
     {
      this.pizarra1=valor;
     }
  public void setValorPizarra2(int valor)
     {
      this.pizarra2=valor;
     }
  public int getValorTurno()
     {
   return turno;
     }
  public void setValorTurno(int valor)
     {
     this.turno=valor;
     }
 }

 class Contador 
 {
   int x;
   public Contador(int x )
   {
     this.x = x;
   }
   public void setX(int x)
   {
     this.x = x;
   }
   public int getX(){
     return x;
   }
 }

class puerta1 extends Thread
 {
    private Turnos turnoa;
    private Contador cnt;
    String name;

    public puerta1(String name,Turnos turnoa,  Contador cnt)
       {
       	this.name = name;
       	this.turnoa=turnoa;
        this.cnt = cnt;
       }

    public void run()
    {
        int entraSale;
     for(;;)
        {
        turnoa.setValorPizarra1(1);

         while(turnoa.getValorPizarra2()==1)
            {
            try{
            sleep(1);
            }catch(InterruptedException e){}

            if (turnoa.getValorTurno()==2)
               {
                turnoa.setValorPizarra1(0);
               	try{
                sleep(1);
                }catch(InterruptedException e){}

               while (turnoa.getValorTurno()==2)
               	{
               	 try{
                 sleep(1);
                 }catch(InterruptedException e){}
               	}

               	turnoa.setValorPizarra1(1);
               }
            }
          cnt.setX(cnt.getX()+1);
          System.out.println(name + ": Ha ingresado a los jardines... " + cnt.getX());
          turnoa.setValorTurno(2);
          turnoa.setValorPizarra1(0);
        try{
            sleep((long)(Math.random()*(1000-300+1)+300));
          }catch(InterruptedException e){}
     }
  }
 }

class puerta2 extends Thread
 {
    private Turnos turnoa;
    private Contador cnt;
    String name;

    public puerta2(String name, Turnos turnoa, Contador cnt)
       {
        this.name = name;
       	this.turnoa=turnoa;
        this.cnt = cnt;
       }

    public void run()
    {
        int entraSale;
     for(;;)
        {
         turnoa.setValorPizarra2(1);

         while(turnoa.getValorPizarra1()==1)
            {
                try{
                    sleep(1);
                    }catch(InterruptedException e){}

            if (turnoa.getValorTurno()==1)
               {
               	turnoa.setValorPizarra2(0);
               	try{
                 sleep(1);
                 }catch(InterruptedException e){}

                while(turnoa.getValorTurno()==1)
               	   {
               		try{
                         sleep(1);
                         }catch(InterruptedException e){}

               	   }
                turnoa.setValorPizarra2(1);
               }
            }
          cnt.setX(cnt.getX()+1);
          System.out.println(name + ": Ha ingresado a los jardines... " + cnt.getX());
          turnoa.setValorTurno(1);
          turnoa.setValorPizarra2(0);
            try{
                sleep((long)(Math.random()*(1000-300+1)+300));
              }catch(InterruptedException e){}
         }
        }
     }


public class jardinesD
   {
    public static void main(String[] args)
       {
       	Turnos turnoa=new Turnos(0,0,1);
        Contador cont = new Contador(0);
       	puerta1 p1=new puerta1("Puerta1",turnoa,cont);
       	puerta2 p2=new puerta2("PUERTA2",turnoa,cont);
       	p1.start();
       	p2.start();
       }
   }
