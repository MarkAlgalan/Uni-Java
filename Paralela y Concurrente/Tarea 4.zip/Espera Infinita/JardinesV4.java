package escuela.jardinesv4;

import static java.lang.Thread.sleep;


class Contador 
  {
    //True = PuertaQueriendoUsarse False = PuertaSinAcción
    boolean pizarra1, pizarra2;
    int x;
    public Contador(int x )
    {
      this.x = x;
    }
    public void setX(int x)
    {
      this.x = x;
    }
    public int getX(){
      return x;
    }
    public void setPizarra(int id, boolean a){
        if(id==2){
            pizarra2= a;
        }
        if(id==1){
            pizarra1 = a;
        }
    }
    public boolean getPizarra(int id){
        switch (id){
            case 2:
                return pizarra2;
            case 1:
                return pizarra1;
        }
     
        System.out.println("Errrrrrrrrrrrrrrorrrrrrrrrrrr");
        return false;
    }
  }

class Puerta extends Thread
  {
    String name;
    Contador cnt;
    int id;
    int idOtro;
   
    public Puerta (String name, Contador cnt,int id )
    {
      this.name = name;
      this.cnt = cnt;
      this.id = id;
      if(id==1){
          idOtro = 2;
      }else{
          idOtro = 1;
      }
    }
    
    public void run()
    {
      //Ahora es infinito
      for(int i= 0;i<20;i++)
      {
        cnt.setPizarra(id, true);

        while(cnt.getPizarra(idOtro)==true){
            cnt.setPizarra(id, false);
            try{
                sleep(50);
            }catch(InterruptedException e){}
            cnt.setPizarra(id, true);
        }

        cnt.setX(cnt.getX()+1);
        System.out.println(name + ": Ha ingresado una persona a los jardines... " + cnt.getX());
       
        cnt.setPizarra(id, false);
      }
    }
  }


public class JardinesV4 {
  public static void main(String[] args) {
    Contador c = new Contador(0);
    Puerta p1 = new Puerta("Puerta 1", c, 1);
    Puerta p2 = new Puerta("Puerta 2", c, 2);
    
    p1.start();
    p2.start();
    try{
      p1.join();
      p2.join();
    }catch(InterruptedException e){}
    System.out.println("TOTAL DE PERSONAS EN LOS JARDINES: " + c.getX());
  }

}

