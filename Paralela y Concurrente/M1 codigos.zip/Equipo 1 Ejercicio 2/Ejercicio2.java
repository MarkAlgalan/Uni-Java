class Hilo1 extends Thread{
    public int[] arreglo = new int[100];
    public int resultado;

    public Hilo1(int arreglo[]){
        resultado = 0;
        this.arreglo = arreglo;
    }

    public void run(){
        for(int i=0; i<100; i++){
            if (arreglo[i]%2==0){
                resultado=resultado+arreglo[i];
            }
        }
        System.out.println("La suma de los pares es: "+resultado);
    }
}

class Hilo2 extends Thread{
    public int[] arreglo = new int[100];
    public int resultado;

    public Hilo2(int arreglo[]){
        resultado = 0;
        this.arreglo = arreglo;
    }

    public void run(){
        for(int i=0; i<100; i++){
            if (arreglo[i]%2!=0){
                resultado=resultado+arreglo[i];
            }
        }
        System.out.println("La suma de los nones es: "+resultado);
    }
}
class Hilo3 extends Thread{
    public int[] arreglo = new int[100];
    public int resultado;

    public Hilo3(int arreglo[]){
        resultado = 1;
        this.arreglo = arreglo;
    }

    public void run(){
        for(int i=0; i<100; i++){
            int j = 2;
            while (arreglo[i] % j != 0) {                              
                j++;
                   
            }
            if (j == arreglo[i]) {  
                resultado = resultado + arreglo[i];       
            }
        }
        System.out.println("La suma de los primos es: "+resultado);
    }
}

class Hilo4 extends Thread{
    public Hilo1 h1;
    public Hilo2 h2;
    public Hilo3 h3;
    public int resultado;
    
    public Hilo4(Hilo1 h1, Hilo2 h2, Hilo3 h3){
        resultado = 0;
        this.h1 = h1;
        this.h2 = h2;
        this.h3 = h3;
    }

    public void run(){
        try {
            h1.join();
            h2.join();
            h3.join();
        } catch (Exception e) {
        }
        resultado = h1.resultado + h2.resultado + h3.resultado;
        System.out.println("El resultado final es: " + resultado);
    }
}

public class Ejercicio2{
    public static void main(String[]args){
        int[] arreglo = new int[100];
        for(int i=0; i<100;i++){
            arreglo[i]=i;
        }

        Hilo1 h1 = new Hilo1(arreglo);
        Hilo2 h2 = new Hilo2(arreglo);
        Hilo3 h3 = new Hilo3(arreglo);
        Hilo4 h4 = new Hilo4(h1,h2,h3);

        h1.start();
        h2.start();
        h3.start();
        h4.start();
    }
} 