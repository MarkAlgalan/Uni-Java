/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ej_x_equipos;

/**
 *
 * @author nuria
 */
class S1 extends Thread
{
int a,d;
double y;
public S1(int a,int d)
{
this.a=a;
this.d=d;
}
public void run()
{
y=a*d;
System.out.println("y= "+y);
}
}
class S2 extends Thread
{
int b,c;
double w;
public S2(int c, int b)
{
this.b=b;
this.c=c;
}
public void run()
{
w = b*c;
System.out.println("w= "+w);
}
}
class S3 extends Thread
{
public S1 s1;
public S2 s2;
public double z;
public S3(S1 s1, S2 s2)
{
this.s1=s1;
this.s2=s2;
}
public void run()
{
try{
s1.join();
s2.join();
}catch(InterruptedException e){}
z=s1.y+s2.w;
System.out.println("z= "+z);
}
}
class S4 extends Thread
{
int b,d;
double E;
public S4(int d, int b)
{
this.b=b;
this.d=d;
}
public void run()
{
E = b*d;
System.out.println("E= "+E);
}
}
class S5 extends Thread
{
public S3 s3;
public S4 s4;
public double X;
public S5(S3 s3,S4 s4)
{
this.s4=s4;
this.s3=s3;
}
public void run()
{
try{
s3.join();
s4.join();
}catch(InterruptedException e){}
double X=s3.z/s4.E;
System.out.println("X= "+X);
}
}
public class Ej_x_equipos {
public static void main(String[] args)
{
int a=2, b=3, c=2, d=2;
S1 h1=new S1(a,d);
S2 h2=new S2(c,b);
S3 h3=new S3(h1,h2);
S4 h4=new S4(d,b);
S5 h5=new S5(h3,h4);
h1.start();
h2.start();
h3.start();
h4.start();
h5.start();
}
}
