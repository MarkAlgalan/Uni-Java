package escuela.ejercicio1correg;

class S1 extends Thread{
    int j;
    S1(){
        
    }
    public void run(){
        j = 0;
        System.out.println("j = "+j);
    }
}
class S2 extends Thread{
    int k;
    public void run(){
        k = 0;
        System.out.println("k = "+k);
    }
}
class S3 extends Thread{
    int j;
    S1 s1;
    S3(S1 s1){
        this.s1 = s1;
    }
    public void run(){
        try{
           s1.join(); 
        }catch(InterruptedException e){       }
        j = s1.j + 10;
        System.out.println("j = "+j);
    }
}
class S4 extends Thread{
    int k;
    S2 s2;
    S4(S2 s2){
        this.s2 = s2;
    }
    public void run(){
        try{
           s2.join(); 
        }catch(InterruptedException e){       }
        k = s2.k + 100;
        System.out.println("k = "+k);
    }
}
class S5 extends Thread{
    int j;
    S3 s3;
    S5(S3 s3){
        this.s3 = s3;
    }
    public void run(){
        try{
           s3.join(); 
        }catch(InterruptedException e){       }
        j = s3.j + 10;
        System.out.println("j = "+j);
    }
}
class S6 extends Thread{
    int k;
    S4 s4;
    S6(S4 s4){
        this.s4 = s4;
    }
    public void run(){
        try{
           s4.join(); 
        }catch(InterruptedException e){       }
        k = s4.k + 100;
        System.out.println("k = "+k);
    }
}
class S7 extends Thread{
    S5 s5;
    S6 s6;
    S7(S5 s5, S6 s6){
        this.s5 = s5;
        this.s6 = s6;
    }
    public void run(){
        try{
            s5.join();
            s6.join();
        }catch(InterruptedException e){}
        System.out.println("S7: Impresion  j = "+s5.j+" ,k = "+s6.k);
    }
}
public class Ejercicio1Correg {

    public static void main(String[] args) {
        S1 hilo1 = new S1();
        S2 hilo2 = new S2();
        S3 hilo3 = new S3(hilo1);
        S4 hilo4 = new S4(hilo2);
        S5 hilo5 = new S5(hilo3);
        S6 hilo6 = new S6(hilo4);
        S7 hilo7 = new S7(hilo5, hilo6);
        
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();
        hilo5.start();
        hilo6.start();
        hilo7.start();
    }
}
