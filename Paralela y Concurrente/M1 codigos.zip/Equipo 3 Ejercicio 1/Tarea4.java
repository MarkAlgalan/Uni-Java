/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package escuela.tarea4;

/**
 *
 * @author joseA
 */
class S1 extends Thread

{
    public int j;
    public S1(int j)
    {
        j=0;
        this.j=j;
    }
    public void run()
    {
        j=j+10;
        System.out.println("J= "+j);
    }

}

class S2 extends Thread

{

    public int k;

    public S2(int k)
    {
        k=0;
        this.k=k;

    }

    public void run()
    {

        k=k+100;
        System.out.println("K= "+k);
    }

}

class S3 extends Thread

{
    public S1 s1;
    public int j;
    public S3(int j, S1 s1)
    {
        j=s1.j;
        this.s1=s1;
        this.j=j;

    }

    public void run()
    {
        try{
            s1.join();
        }catch(InterruptedException e){;}
        j=s1.j+10;
        System.out.println("J= "+j);

    }

}


class S4 extends Thread

{
    public S2 s2;
    int k;

    public S4(S2 s2, int k)

    {

        this.s2=s2;
        this.k=k;
    }


    public void run()
    {
        try{
            s2.join();
        }catch(InterruptedException e){;}
        k=s2.k+100;
        System.out.println("K= "+k);
    }

}

class S5 extends Thread

{
    public int j;
    public S3 s3;

    public S5(int j,S3 s3)

    {
        j=s3.j;
        this.j=j;
        this.s3=s3;

    }

    public void run()

    {
        try{
            s3.join();
        }catch(InterruptedException e){;}

        j=s3.j+10;
        System.out.println("J= "+j);

    }

}

class S6 extends Thread

{
    public int k;
    public S4 s4;

    public S6(int k,S4 s4)

    {
        k=2;
        this.k=k;
        this.s4=s4;

    }

    public void run()

    {
        try{
            s4.join();
        }catch(InterruptedException e){;}

        k=s4.k+100;
        System.out.println("K= "+k);

    }

}

class S7 extends Thread

{
    public int k,j;
    public S5 s5;
    public S6 s6;

    public S7(int k, int j,S5 s5,S6 s6)

    {

        this.k=k;
        this.s5=s5;
        this.s6=s6;
        this.j=j;

    }

    public void run()

    {
        try{
            s5.join();
            s6.join();
        }catch(InterruptedException e){;}

        j=s5.j;
        k=s6.k;
        System.out.println("Los resultados finales son "+"K= "+k+" J= "+j);

    }

}



public class Tarea4

{
    public static void main(String args[])
    {
        int j=0, k=0;

        S1 s1=new S1(j);
        S2 s2=new S2(k);
        S3 s3=new S3(j,s1);
        S4 s4=new S4(s2,k);
        S5 s5=new S5(j,s3);
        S6 s6=new S6(k,s4);
        S7 s7=new S7(k,j,s5,s6);

        s1.start();
        s2.start();
        s3.start();
        s4.start();
        s5.start();
        s6.start();
        s7.start();

        try{
            s7.join();
        }catch(InterruptedException e){;}



    }

}
