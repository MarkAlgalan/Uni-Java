package Ejercicio2;

// Clase principal que contiene el método main para iniciar los hilos
public class Numeros {
    public static void main(String[] args) {
        // Crear instancias de los objetos Runnable (h1, h2, h3)
        pares h1 = new pares();
        impares h2 = new impares();
        primos h3 = new primos();

        // Crear instancias de los objetos Thread asociados a los objetos Runnable
        Thread t1 = new Thread(h1);
        Thread t2 = new Thread(h2);
        Thread t3 = new Thread(h3);

        // Iniciar el primer hilo (pares)
        t1.start();

        try {
            // Esperar un segundo antes de iniciar el siguiente hilo (impares)
            Thread.sleep(1000);
            t2.start();
            // Esperar un segundo antes de iniciar el último hilo (primos)
            Thread.sleep(1000);
            t3.start();
        } catch (InterruptedException e) {
            // Manejar la excepción si ocurre algún problema con la espera
        }
        
        // Esperar a que todos los hilos terminen su ejecución
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            // Manejar la excepción si ocurre algún problema con la espera
        }
    }
}

// Clase para encontrar números pares
class pares implements Runnable {
    private int num[] = new int[100];
    private int i;

    public pares() {
        // Inicializar el arreglo con los primeros 100 números naturales
        for (i = 0; i < 100; i++) {
            num[i] = i + 1;
        }
    }

    @Override
    public void run() {
        // Iterar sobre el arreglo para encontrar los números pares y mostrarlos
        for (i = 0; i < 100; i++) {
            if (num[i] % 2 == 0) {
                System.out.printf("Número %d es par%n\n", num[i]);
            }
        }
    }
}

// Clase para encontrar números impares
class impares implements Runnable {
    private int[] num = new int[100];
    private int i;

    public impares() {
        // Inicializar el arreglo con los primeros 50 números impares
        for (i = 0; i < 50; i++) {
            num[i] = 2 * i + 1;
        }
    }

    @Override
    public void run() {
        // Iterar sobre el arreglo para encontrar los números impares y mostrarlos
        for (i = 0; i < 50; i++) {
            if ((num[i] % 2) != 0) {
                System.out.printf("Número %d es impar%n\n", num[i]);
            }
        }
    }
}

// Clase para encontrar números primos
class primos implements Runnable {
    private int[] num = new int[100];
    private int i;

    public primos() {
        // Inicializar el arreglo con los primeros 100 números naturales
        for (i = 0; i < 100; i++) {
            num[i] = i;
        }
    }

    @Override
    public void run() {
        // Iterar sobre el arreglo para encontrar los números primos y mostrarlos
        for (i = 0; i < 100; i++) {
            if (esPrimo(num[i])) {
                System.out.printf("Número %d es primo%n\n", num[i]);
            }
        }
    }

    // Método para verificar si un número es primo
    private boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i * i <= numero; i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}
