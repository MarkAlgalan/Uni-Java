
package escuela.tarea5;

class S1 extends Thread

{
    public int i;
    public S1(int i)
    {
        i=10;

        this.i=i;
    }
    public void run()
    {
        setPriority(MAX_PRIORITY);
        for(;;i--) {
            if (i>1){
                setPriority(i);
            }
            else{
                setPriority(MIN_PRIORITY);
            }

            System.out.println("Soy el hilo 1 y mi prioridad es = " + getPriority());
            try{
                Thread.sleep(1000);
            }catch(InterruptedException e){}
        }

    }

}

class S2 extends Thread

{

    public int  i;

    public S2( int i)
    {
        i=1;

        this.i=i;

    }

    public void run()
    {
        for(;;i++) {
            if(i<=10) {
                setPriority(i);
            }
            else{
                setPriority(MAX_PRIORITY);
            }
            System.out.println("Soy el hilo 2 y mi prioridad es = " + getPriority());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
        }
    }

}

public class Tarea5

{
    public static void main(String args[])
    {
        int i=0;

        S1 s1=new S1(i);
        S2 s2=new S2(i);

        s1.start();
        s2.start();

        try{
            s1.join();
            s2.join();
        }catch(InterruptedException e){}

    }

}
