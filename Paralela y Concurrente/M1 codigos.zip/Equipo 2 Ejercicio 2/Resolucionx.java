
package escuela.resolucionx;


public class Resolucionx {

    static int x = 0;

    static class P1 extends Thread {
        public void run() {
        x = x + 10;
        }
    }

    static class P2 extends Thread {
        public void run() {
            int result;
            if (x > 100){
                result = x;
                } else {
                    result = x - 50;
                    }

        System.out.println(result);
        }
    }

    public static void main(String[] args) {
        x = 100;

        Thread p1 = new P1();
        Thread p2 = new P2();

        p1.start();
        p2.start();

        try {
            p1.join();
            p2.join();
        } catch (InterruptedException e) {}
    }
}
