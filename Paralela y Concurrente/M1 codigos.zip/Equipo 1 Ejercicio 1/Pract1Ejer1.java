class S1 extends Thread {
  public int A,B,C;
  public S1(int B,int C) {
    this.B = B;
    this.C = C;
  }
  public void run() {
    A = B+C;
    System.out.println("A = "+A);
  }
}

class S2 extends Thread {
  public S1 s1;
  public int C,D;
  public S2(int D,S1 s1) {
    this.s1 = s1;
    this.D = D;
  }
  public void run() {
    try {
      s1.join();
    } catch (InterruptedException e) {}
    C = s1.B*D;
    System.out.println("C = "+C);
  }
}

class S3 extends Thread {
  public int S;
  public S3() {}
  public void run() {
    this.S = 0;
    System.out.println("S = "+S);
  }
}

class S4 extends Thread {
  public int S;
  public int[] X;
  public S3 s3;
  public S4(S3 s3,int[] X) {
    this.s3 = s3;
    this.X = X;
  }
  public void run() {
    try {
      s3.join();
    } catch (InterruptedException e) {}
    S = s3.S + X[0];
    System.out.println("S = "+S);
  }
}

class S5 extends Thread {
  public int S;
  public int[] X;
  public S4 s4;
  public S5(S4 s4) {
    this.s4 = s4;
    this.X = s4.X;
  }
  public void run() {
    try {
      s4.join();
    } catch (InterruptedException e) {}
    S = s4.S + X[1];
    System.out.println("S = "+S);
  }
}

class S6 extends Thread {
  public int S;
  public int[] X;
  public S5 s5;
  public S6(S5 s5) {
    this.s5 = s5;
    this.X = s5.X;
  }
  public void run() {
    try {
      s5.join();
    } catch (InterruptedException e) {}
    S = s5.S + X[2];
    System.out.println("S = "+S);
  }
}

class S7 extends Thread {
  public int S;
  public int[] X;
  public S6 s6;
  public S7(S6 s6) {
    this.s6 = s6;
    this.X = s6.X;
  }
  public void run() {
    try {
      s6.join();
    } catch (InterruptedException e) {}
    S = s6.S + X[3];
    System.out.println("S = "+S);
  }
}

class S8 extends Thread {
  public int C;
  public S7 s7;
  public S2 s2;
  public S8(S7 s7,S2 s2) {
    this.s7 = s7;
    this.s2 = s2;
    this.C = s2.C;
  }
  public void run() {
    try {
      s7.join();
      s2.join();
    } catch (InterruptedException e) {}
    if (s7.S >= 1000) {
      C = s2.C * 2;
    }
    System.out.println("C = "+C);
  }
}

public class Pract1Ejer1 {
  public static void main(String[] args) {
    int[] X = {1000,200,20,1};
    int B = 2, C = 3, D = 3;

    S1 hilo1 = new S1(2, 3);
    S2 hilo2 = new S2(3, hilo1);
    S3 hilo3 = new S3();
    S4 hilo4 = new S4(hilo3, X);
    S5 hilo5 = new S5(hilo4);
    S6 hilo6 = new S6(hilo5);
    S7 hilo7 = new S7(hilo6);
    S8 hilo8 = new S8(hilo7, hilo2);

    hilo1.start();
    hilo2.start();
    hilo3.start();
    hilo4.start();
    hilo5.start();
    hilo6.start();
    hilo7.start();
    hilo8.start();


    try {
      hilo8.join();
    } catch (InterruptedException e) {}

  }
}
