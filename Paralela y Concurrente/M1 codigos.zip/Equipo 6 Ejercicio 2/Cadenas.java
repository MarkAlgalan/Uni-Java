/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cadenas;

/**
 *
 * @author nuria
 */
import java.util.Scanner;

public class Cadenas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduce un número entero:");
        int num = scanner.nextInt();
        scanner.nextLine();  // consume newline left-over

        String[] words = new String[num];
        System.out.println("Introduce " + num + " cadenas:");
        for (int i = 0; i < num; i++) {
            words[i] = scanner.nextLine();
        }

       // System.out.println("Introduce el número de veces que cada cadena debe ser impresa:");
        //int times = scanner.nextInt();
        //scanner.close();

         System.out.print("El resultado de lanzar los hilos es el siguiente: \n"); 
        for (String word : words) {
            Thread thread = new Thread(() -> {          
                for (int i = 0; i < num; i++) {
                    System.out.println(word);
                }
            });
            thread.start();
        }  
    }
}
