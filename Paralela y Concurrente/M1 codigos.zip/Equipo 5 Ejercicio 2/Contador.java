package escuela.contador;



class Colocador extends Thread{

	int numHojas, numero;

	public Colocador(int num, int numero){
		numHojas=num;
		this.numero=numero;
	}

	public void run(){
		for(int i=0;i<numHojas;i++)
			System.out.println("Colocador " + numero + ": Colocando hoja " + (i+1));
		System.out.println("Colocador " + numero + " terminado");
	}
}

public class Contador extends Thread{

	Colocador persona1, persona2, persona3;

	public Contador(Colocador p1, Colocador p2, Colocador p3){
		persona1=p1;
		persona2=p2;
		persona3=p3;
	}

	public void run(){
		persona1.start();
		persona2.start();
		persona3.start();
		try{
			persona1.join();
			persona2.join();
			persona3.join();
		}catch(InterruptedException e){}
		System.out.println("Hay " + (persona1.numHojas+persona2.numHojas+persona3.numHojas) + " hojas en total");
	}

	public static void main(String[] args){
		Colocador p1 = new Colocador(50, 1);
		Colocador p2 = new Colocador(100, 2);
		Colocador p3 = new Colocador(200, 3);
		Contador c = new Contador(p1,p2,p3);
		c.start();
	}
}
