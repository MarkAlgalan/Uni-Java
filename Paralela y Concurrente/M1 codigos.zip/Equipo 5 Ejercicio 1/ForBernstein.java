package escuela.forbernstein;

public class ForBernstein {

    public static void main(String[] args) {
        S1 s1 = new S1(1);
        S2 s2 = new S2(2);
        S3 s3 = new S3(s1);
        S4 s4 = new S4(s2);
        S5 s5 = new S5(s3);
        S6 s6 = new S6(s4);
        
        s1.start();
        s2.start();
        s3.start();
        s4.start();
        s5.start();
        s6.start();
    }
}

class S1 extends Thread{
    public int a3;
    public int a1;
    public S1(int a1){
        this.a1 = a1;
    }
    public void run(){
        a3=a1+4;
        System.out.println("a[3] = "+a3);
    }
}
class S2 extends Thread{
    public int a4;
    public int a2;
    public S2(int a2){
        this.a2 =a2;
    }
    public void run(){
        a4 = a2+4;
        System.out.println("a[4] = "+a4);
    }
}
class S3 extends Thread{
    public int a5;
    public S1 s1;
    public S3(S1 s1){
        this.s1 = s1;
    }
    public void run(){
        try{
            s1.join();
        }catch(InterruptedException e){}
        a5 = s1.a3+4;
        System.out.println("a[5] = "+a5);
    }
}
class S4 extends Thread{
    public int a6;
    public S2 s2;
    public S4(S2 s2){
        this.s2 = s2;
    }
    public void run(){
        try{
            s2.join();
        }catch(InterruptedException e){}
        a6 = s2.a4 + 4;
        System.out.println("a[6] = "+a6);
    }
}
class S5 extends Thread{
    public int a7;
    public S3 s3;
    public S5(S3 s3){
        this.s3 = s3;  
    }
    public void run(){
        try{
            s3.join();
        }catch(InterruptedException e){}
        a7 = s3.a5 + 4;
        System.out.println("a[7] = "+a7);
    }
}

class S6 extends Thread{
    public int a8;
    public S4 s4;
    public S6(S4 s4){
        this.s4 = s4; 
    }
    public void run(){
        try{
            s4.join();
        }catch(InterruptedException e){}
        a8 = s4.a6+4;
        System.out.println("a[8] = "+a8);
    }
}