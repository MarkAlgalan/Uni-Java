/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package escuela.ejercicio3;




class S1 extends Thread{
    float t1, a, b;
    
    public S1 (float a,float b){
        this.a = a;
        this.b = b;
    }
    
    public void run(){
        t1 = a * b;
        System.out.println("T1 = " + t1);
    }
}


class S2 extends Thread{
    S1 s1;
    float t2, c;
    
    public S2 (S1 s1, float  c){
        this.s1 = s1;
        this.c = c;
    }
    
    public void run(){
        try {
            s1.join(); 
        } catch (InterruptedException e) {
        }
        t2 = s1.t1 + c;
        
        System.out.println("T2 = " + t2);
    }
    
}

class S3 extends Thread{
    S1 s1;
    float t3, d;
   
    public S3 (S1 s1, float  d){
        this.s1 = s1;
        this.d = d;
    }
    
    public void run(){
        try {
            s1.join(); 
        } catch (InterruptedException e) {
        }
        t3 = s1.t1 - d;

        System.out.println("T3 = " + t3);
    }
    
}


class S4 extends Thread{
    S2 s2;
    S3 s3;
    float t4;
    
    public S4 (S2 s2, S3 s3){
       this.s2 = s2;
       this.s3 = s3;
    }
    
    public void run(){
        try {
            s2.join(); 
            s3.join(); 
        } catch (InterruptedException e) {
        }
        t4 =  (s2.t2 / s3.t3);
        
        System.out.println("T4 = " + t4);
    }
    
}


public class Ejercicio3 {

   
    public static void main(String[] args) {
        float a = 3, b= 4, c= 5, d= 6;
        S1 s1 = new S1(a, b);
        S2 s2 = new S2(s1, c);
        S3 s3 = new S3(s1, d);
        S4 s4 = new S4(s2, s3);
        
        s1.start();
        s2.start();
        s3.start();
        s4.start();
        
        
        try {
            
            s1.join();
            s2.join();
            s3.join();
            s4.join();
        } catch (InterruptedException e) {}
        
    }
    
}