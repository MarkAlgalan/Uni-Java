

import java.util.Random;

class N1 extends Thread {
    public int[] linea;  
    public int nNi;

    public N1(int nNi, int[] linea) {
        this.nNi = nNi;
        this.linea = linea;
    }

    public void run() {
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            int dado = random.nextInt(6) + 1;
            linea[i] = dado;
        }
    }
}

class observador extends Thread {
    private int[][] matrizResultados;
    
    public observador(int[][] matrizResultados) {
        this.matrizResultados = matrizResultados;
    }

    public void run() {
        for (int i = 0; i < matrizResultados.length; i++) {
            int suma = matrizResultados[i][0] + matrizResultados[i][1] + matrizResultados[i][2];

            if (suma == 7 ) {
                if(matrizResultados[i][0] % 2!=0 && matrizResultados[i][1] % 2!=0 && matrizResultados[i][2] % 2!=0){
                    System.out.println("Niño " + (i + 1) + " es ganador!");
                }else {
                System.out.println("Niño " + (i + 1) + " es perdedor.");
            }
            } else {
                System.out.println("Niño " + (i + 1) + " es perdedor.");
            }
        }
    }
}


public class dados {
    public static void main(String[] args) {
        
        for(int k=0;k<10;k++){
        int[][] matrizResultados = new int[5][3];
        
        N1 nino1 = new N1(0, matrizResultados[0]);
        N1 nino2 = new N1(1, matrizResultados[1]);
        N1 nino3 = new N1(2, matrizResultados[2]);
        N1 nino4 = new N1(3, matrizResultados[3]);
        N1 nino5 = new N1(4, matrizResultados[4]);
        
        
        nino1.start();
        nino2.start();
        nino3.start();
        nino4.start();
        nino5.start();
        try {
            nino1.join();
            nino2.join();
            nino3.join();
            nino4.join();
            nino5.join();
        } catch (InterruptedException e) {}
        
     
        System.out.println("\n\nResultados:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Niño " + (i + 1) + ": ");
            for (int j = 0; j < 3; j++) {
                System.out.print(matrizResultados[i][j] + " ");
            }
            System.out.println();
        }
        
        observador nino6 = new observador(matrizResultados);
        nino6.start();
        try {
            nino6.join();
        } catch (InterruptedException e) {}
    }
    }
}
