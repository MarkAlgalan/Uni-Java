import java.util.Scanner;
import java.lang.Thread;

public class FormulaGeneral{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese los valores de a, b y c
        System.out.println("Ingrese el valor de a:");
        double a = scanner.nextDouble();

        System.out.println("Ingrese el valor de b:");
        double b = scanner.nextDouble();

        System.out.println("Ingrese el valor de c:");
        double c = scanner.nextDouble();

        // Crear objetos para realizar los cálculos en hilos separados
        Dos dos = new Dos(a);
        Cuatro cuatro = new Cuatro(c, a);
        Doble doble = new Doble(b);
        Resta resta = new Resta(doble, cuatro);
        Res res= new Res(b, dos, resta);
        
        // Iniciar los hilos para realizar los cálculos
        res.start();

        scanner.close(); // Cerrar el scanner después de utilizarlo
    }
}

// Clase para calcular 2*a
class Dos extends Thread {
    public double a, dos;

    public Dos(double a){
        this.a=a;
        dos=0;
    }
    
    @Override
    public void run(){
        dos = 2*a;
        System.out.print("\nResultado 2a: "+ dos);
    }
    
    public double getDos() {
        return dos;
    }
}

// Clase para calcular 4*a*c
class Cuatro extends Thread {
    private double c, a, cuatro;

    public Cuatro(double c, double a) {
        this.c = c;
        this.a = a;
        cuatro = 0;
    }

    @Override
    public void run() {
        cuatro = 4 * (a * c);
        System.out.println("\nResultado 4ac: " + cuatro);
    }
    
    public double getCuatro() {
        return cuatro;
    }
}

// Clase para calcular b^2
class Doble extends Thread {
    private double b, doble;

    public Doble(double b) {
        this.b = b;
        doble = 0;
    }

    @Override
    public void run() {
        doble = b * b;
        System.out.println("\nResultado b2: " + doble);
    }
    
    public double getDoble() {
        return doble;
    }
}

// Clase para calcular b^2 - 4*a*c
class Resta extends Thread {
    private double resta;
    private Doble doble;
    private Cuatro cuatro;

    public Resta(Doble doble, Cuatro cuatro) {
        this.cuatro = cuatro;
        this.doble = doble;
        resta = 0;
    }

    @Override
    public void run() {
	doble.start();
	cuatro.start();
	try{
		doble.join();
		cuatro.join();
	}catch(InterruptedException e){}
        resta = doble.getDoble() - cuatro.getCuatro();
        System.out.println("\nResultado b2 - 4ac: " + resta);
        if(resta<0){
            System.out.println("\nNo existe un resultado");
        }
    }
    
    public double getResta() {
        return resta;
    }
}

// Clase para calcular las raíces usando la fórmula general
class Res extends Thread {
    private double r,r1, b;
    private Dos dos;
    private Resta resta;

    public Res(double b, Dos dos, Resta resta) {
        r = 0;
        r1=0;
        this.b = b;
        this.dos = dos;
        this.resta = resta;
    }

    @Override
    public void run() {
	dos.start();
	resta.start();
	try{
		dos.join();
		resta.join();
	}catch(InterruptedException e){}
        if(resta.getResta()<0){
            System.out.println("\nNo existe una solucion");
        }else{
        // Calcular las raíces usando la fórmula general
        r = ((-b)-(Math.sqrt(resta.getResta())/dos.getDos()));
        r1 = ((-b)+(Math.sqrt(resta.getResta())/dos.getDos())) ;  

        // Imprimir las raíces
        System.out.println("\nEl valor de x1: "+ r);
        System.out.println("\nEl valor de x2: "+ r1);
        }
    }
}
