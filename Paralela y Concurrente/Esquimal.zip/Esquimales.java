import java.lang.Thread;
import java.util.Random;
import java.util.ArrayList;

class Esquimal extends Thread{
	int id, pescado;
	Pizarron pizarron;

	public Esquimal(int id, int pescado, Pizarron p){
		this.id = id;
		this.pescado = pescado;
		pizarron = p;
	}

	public void run(){
		while(pescado>0){
			while(pizarron.getTurno()!=id){
				try{
					synchronized(pizarron){
						pizarron.wait();
					}
				}catch(InterruptedException e){}
			}
			pescado--;
			System.out.println("Esquimal " + id + ": Pescando ... " + pescado + " peces restantes");
			pizarron.nuevoTurno(id);
			synchronized(pizarron){
				pizarron.notifyAll();
			}
		}
		pizarron.quitar(id);
		System.out.println("Esquimal " + id + ": Termine de pescar");
	}
}

class Pizarron{
	int turno;
	ArrayList<Integer> activos;
	Random rand;
	
	public Pizarron(int turnoInicial, int size){
		turno = turnoInicial;
		activos = new ArrayList<Integer>();
		rand = new Random();
		for(int i=0;i<size;i++)
			activos.add(i+1);
	}

	public void nuevoTurno(int id){
		int turnoNuevo=0;
		do{
			turnoNuevo=rand.nextInt(activos.size());
		}while((activos.get(turnoNuevo)==id)&&(activos.size()>1));
		turno=activos.get(turnoNuevo);
		System.out.println("Siguiente turno es: " + turno);
	}

	public void quitar(int id){
		activos.remove(new Integer(id));
	}

	public synchronized int getTurno(){
		return turno;
	}
}

public class Esquimales{
	public static void main(String args[]){
		Pizarron p = new Pizarron(1, 5);
		Esquimal esquimal1 = new Esquimal(1, 15, p);
		Esquimal esquimal2 = new Esquimal(2, 10, p);
		Esquimal esquimal3 = new Esquimal(3, 20, p);
		Esquimal esquimal4 = new Esquimal(4, 30, p);
		Esquimal esquimal5 = new Esquimal(5, 35, p);

		esquimal1.start();
		esquimal2.start();
		esquimal3.start();
		esquimal4.start();
		esquimal5.start();
		try{
			esquimal1.join();
			esquimal2.join();
			esquimal3.join();
			esquimal4.join();
			esquimal5.join();
		}catch(InterruptedException e){}
	}
}